<?php
    define("BASE_URLS","http://localhost/Thi_cuoi_ky/");
    define("DB_HOST","localhost");
    define("DB_NAME","schedule_management");
    define("DB_USER","root");
    define("DB_PWD","");
?>
