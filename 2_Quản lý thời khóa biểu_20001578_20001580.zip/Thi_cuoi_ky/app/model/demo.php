<?php
require_once "common/database.php";
class demo extends database{
    public function __construct(){
        
    }
}

?>