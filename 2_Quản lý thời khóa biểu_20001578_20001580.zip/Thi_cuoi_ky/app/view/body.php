<?php
if (isset($view)){
    include_once $view;
}
?>