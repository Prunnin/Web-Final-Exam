</body>
<script src="web/javascript/jquery-3.6.0.min.js"></script>
<script src = "web/javascript/footer.js"></script>
<script src = "web/javascript/teacher.js"></script>
</html>