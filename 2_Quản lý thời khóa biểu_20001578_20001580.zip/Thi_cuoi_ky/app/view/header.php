<?php include_once "app/common/define.php"; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <base href="<?php echo BASE_URLS; ?>">
    <link href="web/css/style.css" rel="stylesheet">
    <title>Home</title>
</head>
<body>