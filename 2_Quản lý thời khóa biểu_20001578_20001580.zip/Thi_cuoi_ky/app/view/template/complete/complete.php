<div class="container">
        <h3>Bạn đã đăng ký thành công môn học</h3>
        <a href="index.php" style="text-decoration: underline;">Trở về trang chủ</a>
</div>