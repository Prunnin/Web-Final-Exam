<?php
session_start();
require_once "app/router.php";
$router = new router();
?>